package finalProject3112;

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;


class AddressBook {
    private ArrayList<Contact> contacts = new ArrayList<>();

    public void addContact(Contact contact) {
        contacts.add(contact);
    }

    public void editContact(int index, Contact newContact) {
        contacts.set(index, newContact);
    }

    public void deleteContact(int index) {
        contacts.remove(index);
    }

    public void displayContacts() {
        for (Contact contact : contacts) {
            System.out.println(contact);
        }
    }

    public void saveContactsToFile(String fileName) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
            for (Contact contact : contacts) { 
                writer.write(contact.getName() + "," + contact.getPhoneNumber() + "," + contact.getEmail());
                writer.newLine();
            }
            System.out.println("Contacts saved successfully");
        } catch (IOException e) { 
            e.printStackTrace();
        }
    }

    public void loadContactsFromFile(String fileName) {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(fileName))) {
            contacts = (ArrayList<Contact>) ois.readObject();
            System.out.println("Contacts loaded successfully!");
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}